/**
 * DATE: 1/23/20
 * NAME: Collision and Interaction and Platform Generator Prototype 1.
 * Author: Tyler Jackson
 * 
 */
 
var GREEN_PLATFORM_WIDTH = 358;
var GREEN_PLATFORM_HEIGHT = 83;
var DEATH_PUDDLE_WIDTH = 287;
var DEATH_PUDDLE_HEIGHT = 214;
function Animation(spriteSheet, startX, startY, frameWidth, frameHeight, frameDuration, frames, loop, reverse) {
    this.spriteSheet = spriteSheet;
    this.startX = startX;
    this.startY = startY;
    this.frameWidth = frameWidth;
    this.frameDuration = frameDuration;
    this.frameHeight = frameHeight;
    this.frames = frames;
    this.totalTime = frameDuration * frames;
    this.elapsedTime = 0;
    this.loop = loop;
    this.reverse = reverse;
}

Animation.prototype.drawFrame = function (tick, ctx, x, y, scaleBy) {
    var scaleBy = scaleBy || 1;
    this.elapsedTime += tick;
    if (this.loop) {
        if (this.isDone()) {
            this.elapsedTime = 0;
        }
    } else if (this.isDone()) {
        return;
    }
    var index = this.reverse ? this.frames - this.currentFrame() - 1 : this.currentFrame();
    var vindex = 0;
    if ((index + 1) * this.frameWidth + this.startX > this.spriteSheet.width) {
        index -= Math.floor((this.spriteSheet.width - this.startX) / this.frameWidth);
        vindex++;
    }
    while ((index + 1) * this.frameWidth > this.spriteSheet.width) {
        index -= Math.floor(this.spriteSheet.width / this.frameWidth);
        vindex++;
    }

    var locX = x;
    var locY = y;
    var offset = vindex === 0 ? this.startX : 0;
    ctx.drawImage(this.spriteSheet,
                  index * this.frameWidth + offset, vindex * this.frameHeight + this.startY,  // source from sheet
                  this.frameWidth, this.frameHeight,
                  locX, locY,
                  this.frameWidth * scaleBy,
                  this.frameHeight * scaleBy);
	
}

Animation.prototype.currentFrame = function () {
    return Math.floor(this.elapsedTime / this.frameDuration);
}

Animation.prototype.isDone = function () {
    return (this.elapsedTime >= this.totalTime);
}

function Background(game) {
	this.bkgr = new Animation(ASSET_MANAGER.getAsset("./img/skyscraper.png"), 0, 0, 1238, 535, 1, 1, true, false);
	this.radius = 200;
	//this.removeFromWorld = false;
	 Entity.call(this, game, 0, 0);
	 this.boundingbox = null;
}

Background.prototype = new Entity();
Background.prototype.constructor = Background;

Background.prototype.update = function () {
}

Background.prototype.draw = function (ctx) {
   this.bkgr.drawFrame(this.game.clockTick, ctx, this.x, this.y);
}

function BoundingBox(x, y, width, height, color) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;

    this.left = x;
    this.top = y;
    this.right = this.left + width;
    this.bottom = this.top + height;
    
    this.color = color
   
}

BoundingBox.prototype.collide = function (oth) {
	if (oth === null) {
		return false;
	}
    if (this.right > oth.left && this.left < oth.right && this.top < oth.bottom && this.bottom > oth.top){
    	oth.color = "Green"
    	return true;
    }
    return false;
}


BoundingBox.prototype.updateBoundingBox = function(theX, theY, theWidth, theHeight){ 
	this.x = theX;
	this.y = theY;
	this.width = theWidth;
	this.height = theHeight;
	this.left = theX;
    this.top = theY;
    this.right = this.left + this.width;
    this.bottom = this.top + this.height;
}

function Sidewalk(game) {
	this.sidewalk = new Animation(ASSET_MANAGER.getAsset("./img/Sidewalk.png"), 0, 0, 128, 60, 0.03, 1, true, false);
	
	this.radius = 200;
	Entity.call(this, game, 0, 500);
	this.boundingbox = null;
}

Sidewalk.prototype = new Entity();
Sidewalk.prototype.constructor = Sidewalk;

Sidewalk.prototype.update = function() { 
}

Sidewalk.prototype.draw = function(ctx) {
	for (var i = 0; i <= 17; i++) {
		this.sidewalk.drawFrame(this.game.clockTick, ctx, this.x + (i * 128) - this.game.camera.x, this.y);
	}
	Entity.prototype.draw.call(this);
}

/**
 * This function creates a generic platform
 * @param 
 * game is the standard game engine
 * x is an double that holds X-Value coordinates of the platform.
 * y is a double that holds the Y-Value of the platform.
 * length is a double that holds the length value of the platform drawn.
 * Height is a double that holds the height of the platform drawn.
 * 
 * @returns a generic platform with an entity call.
 * 
 * TODO: Add an addition paramater with a sprite animation to 
 * 		 fill in over the platform/shape drawn.
 */
function Platform(game, x, y, length, height, color) {
	this.radius = 100;
	this.color = color;
	this.length = length;
	this.height = height
	this.x = x;
	this.y = y;
 	this.animation = null;
	if (this.color === "Green") {
		this.length = 358;
		this.height = 83;
		this.animation = new Animation(ASSET_MANAGER.getAsset("./img/platform.png"), 48, 445, 358, 83, 1, 1, true, false);
		this.boundingbox = new BoundingBox(x, y, length, height);
	} 
	if (this.color === "Red") {
		this.animation = new Animation(ASSET_MANAGER.getAsset("./img/puddle.png"), 1732, 1070, 287, 214, 0.25, 3, true, false);
		this.boundingbox = new BoundingBox(x + 60, y, 200, 80);
	}
	else {
		this.boundingbox = new BoundingBox(x, y, length, height);
	}
    

	
	Entity.call(this, game, x, y)
}
Platform.prototype = new Entity();
Platform.prototype.constructor = Platform;

Platform.prototype.update = function (ctx) {
	if (this.color === "Red") {
		//alert(this.animation.elapsedTime + " " + this.animation.totalTime);
		if (this.animation.elapsedTime === 0) {
			//this.elapsedTime = 0;
			this.animation.reverse = !this.animation.reverse;
			this.animation.elapsedTime += this.animation.frameDuration;
			
			//alert(this.animation.reverse + " " + this.animation.elapsedTime);
		}
	} if (this.color === "Blue") {
		if (this.animation.isDone()) {
			this.color = "Red";
			this.animation = new Animation(ASSET_MANAGER.getAsset("./img/puddle.png"), 1732, 1070, 287, 214, 0.25, 3, true, false);
		}
		
	}
}
Platform.prototype.draw = function (ctx) {
	if (this.animation !== null) {
		if (this.color === "Red") {
			this.animation.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y - 170);
        ctx.strokeStyle = this.boundingbox.color;
        ctx.strokeRect(this.boundingbox.x - this.game.camera.x, this.boundingbox.y, this.boundingbox.width, this.boundingbox.height);
		} else if (this.color === "Green") {
			this.animation.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y);
			
        ctx.strokeStyle = this.boundingbox.color;
        ctx.strokeRect(this.boundingbox.x - this.game.camera.x, this.boundingbox.y, this.boundingbox.width, this.boundingbox.height);
		}
		 else if (this.color === "Blue") {
			this.animation.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y - 140);
			
        ctx.strokeStyle = this.boundingbox.color;
        ctx.strokeRect(this.boundingbox.x - this.game.camera.x, this.boundingbox.y, this.boundingbox.width, this.boundingbox.height);
		}
	}
	else {
		ctx.fillStyle = this.color;
		ctx.fillRect(this.x - this.game.camera.x,this.y,this.length,this.height);
	}
    Entity.prototype.draw.call(this);
}

function Lamp(game, x, y) {
	this.offAnim = new Animation(ASSET_MANAGER.getAsset("./img/lamp.png"), 0, 0, 74, 373, 1, 1, true, false);
	this.onAnim = new Animation(ASSET_MANAGER.getAsset("./img/lamp.png"), 76, 0, 74, 373, 1, 1, true, false);
	this.flag = false;
	Entity.call(this, game, x, 130);
}

Lamp.prototype = new Entity();
Lamp.prototype.constructor = Lamp;

Lamp.prototype.update = function() {
	if (this.game.cat.x >= this.x - 150 && this.game.cat.x <= this.x + 150) {
		this.flag = true;
	} else {
		this.flag = false;
	}
}
Lamp.prototype.draw = function(ctx) {

	if (this.flag) {
		this.onAnim.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y);
	} else {
		this.offAnim.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y);
	}
		
}
function Bird(game, x, y, type) {	
	this.bird = new Animation(ASSET_MANAGER.getAsset("./img/bird.png"), 35, 35, 185,70, 0.1, 4, true, false)
	this.reverseBird = new Animation(ASSET_MANAGER.getAsset("./img/bird.png"), 30, 600, 185,70, 0.1, 4, true, false)
	this.attackBird = new Animation(ASSET_MANAGER.getAsset("./img/bird.png"), 30, 400, 185,100, 0.1, 1, true, false)
	this.reverseAttack = new Animation(ASSET_MANAGER.getAsset("./img/bird.png"), 200, 770, 185,100, 0.1, 1, true, false)
	
	this.tx = 0; //Target Location
	this.ty = 0; 
	
	this.vx = 0; //Velocity
	this.vy = 0;
	
	this.distance = 0;
	this.defaultHeight = y - 100
	this.type = "Fly"
	this.length = 50;
	this.height = 100
	this.start = x
	this.x = x;
	this.y = y - 150;
	this.type = type
	this.count = 0;  	//To determine how long the bird will go in an attack dive
	this.count2 = 0;	//To determine how long the bird will retreat upwards
	this.leftCheck = true;	//To determine when to go left or right.
	this.rightCheck = false
	this.boundingbox = new BoundingBox(this.x - 150, this.y, 300, 100, "Purple"); //For testing detection
	this.lastX = this.x	
	this.lastY = this.y
	this.leftAttack = false;	
	this.rightAttack = false;
	this.leftRetreat = false;
	this.rightRetreat = false;
	Entity.call(this, game, x , y )
}
Bird.prototype = new Entity();
Bird.prototype.constructor = Enemy;

Bird.prototype.update= function() {
	this.lastX = this.x
	this.lastY = this.y
	this.boundingbox = new BoundingBox(this.x - 150, this.y, 300, 500, "Purple");
	/**
	 * This will detect when it should switch from the default passive mode to attack mode.
	 * Fly mode will have the bird fly back and forth from one fixed position to another.
	 * Attack mode will be permenant when the bird detects the cat and attacks it.
	 */
	if (this.game.cat.x >= this.x - 100 && this.game.cat.x <= this.x + 100) {
		
		this.boundingbox.color = "Red"
		this.type = "Attack"
		
	} 
	var cat = this.game.cat
	if(this.count === 0){	//This will determine where the cat is located at and attack at that position.
		this.tx = cat.x +50
		this.ty = cat.y +50
		var dx = this.tx - this.x;
	    var dy = this.ty - this.y;
	    this.vx = dx
	    this.vy = dy
	    this.distance = Math.sqrt(dx * dx + dy * dy);
	   
	}
	
	if(this.type === "Fly"){
		if(this.count2 === 0){
			this.leftCheck = false;
			this.rightCheck = true
		}
		if(this.count2 === 100){
			this.leftCheck = true;
			this.rightCheck = false
		} 
		if(this.leftCheck){
			this.x -= 4
			this.count2--
			
		}
		if(this.rightCheck){
			this.x += 4
			this.count2++
		}
		if(this.y > this.defaultHeight){
			this.y -= 5
		}
		if(this.y < this.defaultHeight){
			this.y = this.defaultHeight
		}
	}
	if(this.type === "Attack"){
		this.count++
		
		if(this.count === 100){
			this.leftCheck = false;
			this.rightCheck = true
		}
		if(this.count === 250){
			this.leftCheck = true;
			this.rightCheck = false
			this.count = 0
		}
		if(this.y < 0){
			this.leftCheck = true;
			this.rightCheck = false
			this.count = 0
		}
		if(this.y > 500){
			this.leftCheck = false;
			this.rightCheck = true
			this.count = 100
		}
		if(this.leftCheck){
			this.x += this.vx/this.distance * 6
			this.y += this.vy/this.distance * 6
		}
		if(this.rightCheck){
			this.y -= this.vy/this.distance * 6
			this.x += this.vx/this.distance * 6
		}
		//Check if the bird is attacking at a downward left angle.
		//Adjust animation to left attack
		if(this.lastX > this.x && this.lastY < this.y  ){
			this.leftAttack = true;
			this.rightAttack = false
			this.leftRetreat = false
			this.rightRetreat = false
		}
		//Check if the bird is attacking at a downward right angle.
		//Adjust animation to left attack
		if(this.lastX < this.x && this.lastY < this.y  ){
			this.leftAttack = false;
			this.rightAttack = true
			this.leftRetreat = false
			this.rightRetreat = false
		}
		//Check if the bird is attacking at a upward left angle.
		//Adjust animation to left movement
		if(this.lastX > this.x && this.lastY > this.y  ){
			this.leftAttack = false;
			this.rightAttack = false
			this.leftRetreat = true
			this.rightRetreat = false
		}
		//Check if the bird is attacking at a upward right angle.
		//Adjust animation to right movement
		if(this.lastX < this.x && this.lastY > this.y  ){
			this.leftAttack = false;
			this.rightAttack = false
			this.leftRetreat = false
			this.rightRetreat = true
		}
	}
	
}
Bird.prototype.draw = function (ctx) {
	
	if(this.type === "Fly" && this.leftCheck || this.type === "Attack" && this.leftRetreat){
		this.bird.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y)

	} 
	if(this.type === "Fly" && this.rightCheck|| this.type === "Attack" && this.rightRetreat){
		this.reverseBird.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y)

	} 
	if(this.type === "Attack" && this.leftAttack){
		this.attackBird.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y)

	} 
	if(this.type === "Attack" && this.rightAttack){
		this.reverseAttack.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y)
	}
	
	ctx.strokeStyle = this.boundingbox.color;
    ctx.strokeRect(this.boundingbox.x - this.game.camera.x, this.boundingbox.y, this.boundingbox.width, this.boundingbox.height);
    Entity.prototype.draw.call(this);
}
function Range(game, x, y, type) {
	//Action animation of the cowboy firing.
	this.ready = new Animation(ASSET_MANAGER.getAsset("./img/cowboy.png"), 240, 370, 190, 160, 0.12, 3, false, false);
	this.readyL = new Animation(ASSET_MANAGER.getAsset("./img/cowboy.png"), 280, 750, 190, 160, 0.12, 3, false, false);
	//Default stance of cowboy when he is not firing.
	this.stance = new Animation(ASSET_MANAGER.getAsset("./img/cowboy.png"), 27, 740, 95, 160, 0.12, 1, true, false);
	this.stanceR = new Animation(ASSET_MANAGER.getAsset("./img/cowboy.png"), 20, 370, 95, 160, 0.12, 1, true, false);
	
	//Animation of first and second bullet facing right. 
	this.bullet = new Animation(ASSET_MANAGER.getAsset("./img/bullet.png"), 15, 240, 61.75, 70, 0.12, 7, true, false);
	this.bullet2 = new Animation(ASSET_MANAGER.getAsset("./img/bullet.png"), 15, 240, 61.75, 70, 0.12, 7, true, false);
	//Animation of first and second bullet facing left.
	this.bulletL = new Animation(ASSET_MANAGER.getAsset("./img/bullet.png"), 5, 0, 61.75, 70, 0.12, 7, true, false);
	this.bullet2L = new Animation(ASSET_MANAGER.getAsset("./img/bullet.png"), 5, 0, 61.75, 70, 0.12, 7, true, false);


	this.game = game
	
	this.left = false;
	this.right = false;
	
	this.rightX = x
	this.leftX = x - 100
	
	this.bx = x + 120;	//Bullet location
	this.by = y - 15;
	
	this.bx2 = x + 120;	//Bullet2 location
	this.by2 = y - 15;
	
	this.vx = 0;	//Velocity
	this.vy = 0;
	
	this.vx2 = 0	//Velocity2
	this.vy2 = 0;
	
	this.bStart = false;	//When each bullet can be fired.
	this.b2Start = false;
	
	this.bleft = false;		//Which direction that bullet will face.
	this.bright = false
	
	this.type = type
	this.length = 50;
	this.height = 100
	this.start = x
	this.x = x;
	this.y = y;
	
	this.boundingbox = new BoundingBox(this.x, this.y, 300, 100, "Purple"); //For testing detection purposes
	this.shoot = false;			//To determine when it can take action against the play through detection
	this.fire = false			//To determine when it can fire a shot at the player.
	this.defaultLeft = false
	this.defaultRight = false
	
	this.count = 0;
	this.accel = 0;
	this.distance = 0;
	this.distance2 = 0;
	
	Entity.call(this, game, this.x , this.y)
}
Range.prototype = new Entity();
Range.prototype.constructor = Range;

Range.prototype.update= function() {
	var cat = this.game.cat
	
	if (this.game.cat.x >= this.x - 500 && this.game.cat.x <= this.x + 500) {
		this.boundingbox.color = "Red"
		this.shoot = true
		
	} else {
		this.boundingbox.color = "Purple"
		this.shoot = false
	}
	if(this.game.cat.x < this.x){
		this.left = true;
		this.right = false;
	} else {
		this.left = false;
		this.right = true;
	}
	
	if(this.count === 0 && this.shoot){
		this.defaultLeft = false
	    this.defaultRight = false
	    this.fire = true
		this.readyL.elapsedTime = 0
		this.ready.elapsedTime = 0
				
		if(this.left){
	    	this.bx = this.x - 120
	    	this.bleft = true
	    	this.bright = false
	    } else {
	    	this.bx = this.x + 120;
	    	this.bleft = false
	    	this.bright = true
	    }
		var tx = cat.x +50 	//Target Location
		var ty = cat.y +50
		var dx = tx - this.bx; //Distance between the x and y axis
	    var dy = ty - this.by;
	    this.vx = dx //Velocity Calculated
	    this.vy = dy
	    this.distance = Math.sqrt(dx * dx + dy * dy); //Total Distance Calculated
	    
	    this.bStart = true
	}
	
	this.count++
	if(this.count === 50 && this.shoot){
	    this.defaultLeft = false
	    this.defaultRight = false
	    this.fire = true
		this.ready.elapsedTime = 0
		this.readyL.elapsedTime = 0
		if(this.left){
		    this.bx2 = this.x - 120
		  } else {
		    this.bx2 = this.x + 120;
		}
		var tx = cat.x +50 	//Target Location
		var ty = cat.y +50
		var dx = tx - this.bx2; //Distance between the x and y axis
	    var dy = ty - this.by2;
	    this.vx2 = dx //Velocity Calculated
	    this.vy2 = dy
	    this.distance2 = Math.sqrt(dx * dx + dy * dy); //Total Distance Calculated
	   
		this.b2Start = true
	}
	if(this.ready.isDone() || this.readyL.isDone()){
		if(this.left){
		    this.defaultLeft = true
		    this.defaultRight = false
		    this.fire = false
		  } else {
		    this.defaultRight = true
		    this.defaultLeft = false
		    this.fire = false
		}
	}
	if(this.bStart){
		this.bx += this.vx/this.distance * 5  //The constant is a scalar to determine speed of the bullet.
		this.by += this.vy/this.distance * 5
	}
	if(this.b2Start){
		this.bx2 += this.vx2/this.distance2 * 5	//The constant is a scalar to determine speed of the bullet.
		this.by2 += this.vy2/this.distance2 * 5
	}
	if(this.count === 100){
		this.bx = this.x + 120;	//Bullet location
		this.by = this.y - 15;
		this.bStart = false
	}
	if(this.count === 150){
		this.bx2 = this.x + 120;	//Bullet location
		this.by2 = this.y - 15;
		this.count = 0;
		this.b2Start = false
	}
	Entity.prototype.update.call(this);	
}
    

Range.prototype.draw = function (ctx) {
	
	if(this.left && this.fire ){
		this.readyL.drawFrame(this.game.clockTick, ctx, this.leftX - this.game.camera.x, this.y)
	} 
	if(this.right && this.fire ){
		this.ready.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y)
	} 
	if(this.defaultRight) {
		this.stanceR.drawFrame(this.game.clockTick, ctx, this.rightX - this.game.camera.x, this.y)
	}
	if(this.defaultLeft){
		this.stance.drawFrame(this.game.clockTick, ctx, this.rightX - this.game.camera.x, this.y)
	}
	//ctx.strokeStyle = this.boundingbox.color;
   // ctx.strokeRect(this.boundingbox.x - this.game.camera.x, this.boundingbox.y, this.boundingbox.width, this.boundingbox.height);
	
	if(this.bStart && this.bright ){
		this.bullet.drawFrame(this.game.clockTick, ctx, this.bx - this.game.camera.x, this.by)
	} else if(this.bleft && this.bStart) {
		this.bulletL.drawFrame(this.game.clockTick, ctx, this.bx - this.game.camera.x, this.by)
	}
	if(this.b2Start && this.bright){
		this.bullet2.drawFrame(this.game.clockTick, ctx, this.bx2 - this.game.camera.x, this.by2);
	} else if (this.bleft && this.b2Start){
		this.bullet2L.drawFrame(this.game.clockTick, ctx, this.bx2 - this.game.camera.x, this.by2);
	}
	
	

}

function distance(a, bx, by) {
    var dx = a.x - bx;
    var dy = a.y - by;
    return Math.sqrt(dx * dx + dy * dy);
}

function Enemy(game, x, y) {
	this.left = new Animation(ASSET_MANAGER.getAsset("./img/dog.png"), 0, 250, 153, 115, 0.1, 4, true, false);
	this.right = new Animation(ASSET_MANAGER.getAsset("./img/dog.png"), 0, 0, 153, 115, 0.1, 6, true, false);
	this.l = true;
	this.r = false
	this.color = "Gold"
	this.length = 50;
	this.height = 100
	this.start = x
	this.x = x;
	this.y = y;
	this.count = 0;
	this.leftCheck = true;
	this.rightCheck = false
	Entity.call(this, game, x - 50, y -12)
}
Enemy.prototype = new Entity();
Enemy.prototype.constructor = Enemy;

Enemy.prototype.update= function() {
	this.x -= 4;
    if (this.x < -150) this.x = 2200;
    Entity.prototype.update.call(this);
	
}

Enemy.prototype.draw = function (ctx) {
	ctx.fillStyle = this.color;
	if(this.r){
		this.right.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y); 
	} else if(this.l){
		this.left.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y); 
	}
	
    //ctx.fillRect(this.x,this.y,this.length,this.height);
    Entity.prototype.draw.call(this);
}

function EnemyIdle(game, x, y) {
	this.idle = new Animation(ASSET_MANAGER.getAsset("./img/dog.png"), 0, 500, 153, 115, 0.6, 3, true, false);
//	this.idleRev = new Animation(ASSET_MANAGER.getAsset("./img/dog.png"), 0, 500, 153, 115, 0.8, 3, false, true);
	this.idleL = new Animation(ASSET_MANAGER.getAsset("./img/dog.png"), 460, 500, 153, 115, 0.6, 3, true, false);
//	this.idleRevL = new Animation(ASSET_MANAGER.getAsset("./img/dog.png"), 345, 500, 153, 115, 0.8, 3, false, true);
//	this.rev = false;
	this.l = true;
	this.r = false;
	this.color = "Gold"
	this.length = 50;
	this.height = 100
	this.start = x
	this.x = x;
	this.y = y;
	this.count = 0;
	this.leftCheck = true;
	this.rightCheck = false
	Entity.call(this, game, x - 50, 400)
}
EnemyIdle.prototype = new Entity();
EnemyIdle.prototype.constructor = EnemyIdle;

EnemyIdle.prototype.update= function() {
	if (this.game.cat.x < this.x) {
		this.l = true;
		this.r = false;
	} else {
		this.l = false;
		this.r = true;
	}
}
EnemyIdle.prototype.idleHelp = function(idleAnim, revAnim) {
	if (idleAnim.isDone()) {
		this.rev = true;
		idleAnim.elapsedTime = 0;
	}
	else if (this.idleRev.isDone()) {
		this.rev = false;
		revAnim.elapsedTime = 0;
	}
	return;
}
EnemyIdle.prototype.draw = function (ctx) {
	ctx.fillStyle = this.color;
	if (this.l) {
		this.idleL.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y);
	} else {
		this.idle.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y);
	}
    //ctx.fillRect(this.x,this.y,this.length,this.height);
    Entity.prototype.draw.call(this);
}
/**
 * This function handles the AI implementation of the dogs.
 * 
 */
function EnemyPace(game, minX, maxX, y, x) {
	this.paceL = new Animation(ASSET_MANAGER.getAsset("./img/dog.png"),0, 250, 152, 115, 0.1, 4, true, false);
	this.pace = new Animation(ASSET_MANAGER.getAsset("./img/dog.png"), 145, 0, 152, 115, 0.1, 5, true, false);
	this.attackR = new Animation(ASSET_MANAGER.getAsset("./img/dog.png"),610, 247, 152, 115, 0.1, 4, false, false);
	this.attackL = new Animation(ASSET_MANAGER.getAsset("./img/dog.png"),305, 365, 152, 120, 0.1, 4, false, false);
	this.boundingbox = new BoundingBox(this.x, this.y, 100, 100, "Purple");
	this.l = true;
	this.r = false;
	this.attack = false
	this.y = y
	this.x = x
	this.minX = minX;	//To determine how far it can walk before it must turn around when pacing.
	this.maxX = maxX;
	this.length = 50;
	this.height = 100
	this.type = "pace"
	Entity.call(this, game, this.x, y)
}
EnemyPace.prototype = new Entity();
EnemyPace.prototype.constructor = EnemyIdle;

EnemyPace.prototype.update= function() {
	this.boundingbox = new BoundingBox(this.x - 400, this.game.cat.y + 50, 800, 100, "Green");
	/**
	 * Pace mode which has the dog walk back and forth in a gaurding pace.
	 */
	if(this.type === "pace"){
		/**
		 * When the dog detects the cat, it switches to attack mode.
		 */
		if (this.game.cat.x >= this.x - 500 && this.game.cat.x <= this.x + 400 && this.game.cat.y + 50 > this.y ) {
			//this.boundingbox.color = "Red"
			this.type = "attack"
		} 
		if(this.type === "pace"){
			if (this.l) {
				if (this.x - 5 >=	this.minX) {
					this.x -= 5;
				} else {
					this.l = false;
					this.r = true;
				}
			} else if (this.r) {
				if (this.x + 5 <= this.maxX) {
					this.x += 5;
				} else {
					this.l = true;
					this.r = false;
				}
			}
		}
	}
	/**
	 * Attack mode which has the dog walk all the way to the player and have it attack it.
	 */
	if(this.type === "attack"){
		this.boundingbox = new BoundingBox(this.x , this.game.cat.y + 50, 200, 100, "Purple");
		this.bound2 = new BoundingBox(this.x , this.y, 200, 100, "Red");
		if(this.game.cat.y + 50 < this.y ){
			this.type = "pace"
		}
		if (this.game.cat.x >= this.x - 60 && this.game.cat.x <= this.x + 140) {
			
			if(this.attackL.isDone() || this.attackR.isDone()){
				if(this.l){
					this.attackL.elapsedTime = 0
				} else {
					this.attackR.elapsedTime = 0
				}
			} 
			this.boundingbox.color = "Red"
			this.attack = true
			
		} else {
			this.attack = false
		}
		/**
		 * This will handle having the dog move to the players ground position.
		 */
		if(this.game.cat.x >= this.x && !this.attack){
			this.x += 5;
			this.l = false
			this.r = true
		} else if(this.game.cat.x <= this.x && !this.attack){
			this.x -= 5;
			this.l = true
			this.r = false
		}
		
	}
}

EnemyPace.prototype.draw = function(ctx) {
	/** For Debugging purposes
	ctx.strokeStyle = this.boundingbox.color;
	ctx.strokeRect(this.boundingbox.x - this.game.camera.x, this.boundingbox.y, this.boundingbox.width, this.boundingbox.height);
	ctx.strokeStyle = this.bound2.color;
	ctx.strokeRect(this.bound2.x - this.game.camera.x, this.bound2.y, this.bound2.width, this.bound2.height);
	*/
	if(this.type === "pace"){
		if (this.l ) {
			this.paceL.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y);
		} else if(this.r ){
			this.pace.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y);
		}
	} else {
		if (this.l && !this.attack) {
			this.paceL.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y);
		} else if(this.r && !this.attack ){
			this.pace.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y);
		}
		if(this.l && this.attack){
			this.attackL.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y);
		} else if(this.r && this.attack){
			this.attackR.drawFrame(this.game.clockTick, ctx, this.x - this.game.camera.x, this.y);
		}
	}
		
}
var ASSET_MANAGER = new AssetManager();

ASSET_MANAGER.queueDownload("./img/catBeta.png");
ASSET_MANAGER.queueDownload("./img/dog.png");
ASSET_MANAGER.queueDownload("./img/Sidewalk.png");
ASSET_MANAGER.queueDownload("./img/skyscraper.png");
ASSET_MANAGER.queueDownload("./img/platform.png");
ASSET_MANAGER.queueDownload("./img/puddle.png");
ASSET_MANAGER.queueDownload("./img/lamp.png");
ASSET_MANAGER.queueDownload("./img/bird.png");
ASSET_MANAGER.queueDownload("./img/cowboy.png");
ASSET_MANAGER.queueDownload("./img/bullet.png");

ASSET_MANAGER.downloadAll(function () {
    console.log("starting up da sheild");
    var canvas = document.getElementById('gameWorld');
    var ctx = canvas.getContext('2d');

    var gameEngine = new GameEngine();
   // var bg = new Background(gameEngine);
	var bg = new Platform(gameEngine, 0, 500, 128 * 17, 100, "Black")
	var skyscraper = new Background(gameEngine);
	//var skyscraper = new Background(gameEngine);

    gameEngine.addPlatform(bg);	
	gameEngine.addEntity(skyscraper);
	/**
	 * Generic platforms can be created, no more need to make a function for each
	 * platform made in the game.
	 * 
	 * var platformName = new Platform(gameEngine, X-Coordinate, Y-Coordinate, Length, Height)
	 *  
	 */
	var plat = new Platform(gameEngine, 100, 430, GREEN_PLATFORM_WIDTH, GREEN_PLATFORM_HEIGHT, "Green");
	var p2 = new Platform(gameEngine, 500, 350, GREEN_PLATFORM_WIDTH, GREEN_PLATFORM_HEIGHT, "Green");
	var p3 = new Platform(gameEngine, 900, 350, GREEN_PLATFORM_WIDTH, GREEN_PLATFORM_HEIGHT, "Green")
	var death = new Platform(gameEngine, 1800, 500, DEATH_PUDDLE_WIDTH, DEATH_PUDDLE_HEIGHT, "Red")
	var bad = new Enemy(gameEngine, 700, 400)
	var bad2 = new Enemy(gameEngine, 1400, 400);
	var bad3 = new EnemyIdle(gameEngine, 500, 400);
	var bad4 = new EnemyIdle(gameEngine, 1300);
	var bad5 = new EnemyPace(gameEngine, 100, 600, 390, 400);
	var bad6 = new EnemyPace(gameEngine, 900, 1300, 390, 500)
	var lamp = new Lamp(gameEngine, 950, 400); 
	var lamp2 = new Lamp(gameEngine, 1300, 400);
	var lamp3 = new Lamp(gameEngine, 1600, 400);
	var sidewalk = new Sidewalk(gameEngine);
	
	
	//var birdFly = new Bird(gameEngine,  600, 100, "Fly")
	var birdAttack = new Bird(gameEngine,  400, 150, "Fly")
	var range = new Range(gameEngine,  500, 200, "Attack")
    gameEngine.addPlatform(plat);
    
    gameEngine.addPlatform(p2);
    
	gameEngine.addEntity(sidewalk); 
    gameEngine.addPlatform(death);
	gameEngine.addEntity(lamp);
	gameEngine.addEntity(lamp2);
	gameEngine.addEntity(lamp3);
	/**
    gameEngine.addEnemy(bad);
	gameEngine.addEnemy(bad2);
	gameEngine.addEnemy(bad3);
	gameEngine.addEnemy(bad4);
	gameEngine.addEnemy(bad5);
	gameEngine.addEnemy(bad6);
	*/
	gameEngine.addEntity(gameEngine.cat);
	gameEngine.addEntity(gameEngine.camera);
    //gameEngine.addEnemy(bad);
	gameEngine.addEnemy(bad5);
	gameEngine.addEnemy(bad6);


	gameEngine.addEnemy(birdAttack);
	gameEngine.addEnemy(range)

	
	//console.log(gameEngine.platforms);
	//console.log(gameEngine.enemies);
	console.log(gameEngine.otherEntities);
	
    gameEngine.init(ctx);
    console.log(gameEngine.cat.platform)
	gameEngine.start();
});