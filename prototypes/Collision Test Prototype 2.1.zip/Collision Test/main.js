/**
 * DATE: 1/23/20
 * NAME: Collision and Interaction and Platform Generator Prototype 1.
 * Author: Tyler Jackson
 * 
 */
function Animation(spriteSheet, startX, startY, frameWidth, frameHeight, frameDuration, frames, loop, reverse) {
    this.spriteSheet = spriteSheet;
    this.startX = startX;
    this.startY = startY;
    this.frameWidth = frameWidth;
    this.frameDuration = frameDuration;
    this.frameHeight = frameHeight;
    this.frames = frames;
    this.totalTime = frameDuration * frames;
    this.elapsedTime = 0;
    this.loop = loop;
    this.reverse = reverse;
}

Animation.prototype.drawFrame = function (tick, ctx, x, y, scaleBy) {
    var scaleBy = scaleBy || 1;
    this.elapsedTime += tick;
    if (this.loop) {
        if (this.isDone()) {
            this.elapsedTime = 0;
        }
    } else if (this.isDone()) {
        return;
    }
    var index = this.reverse ? this.frames - this.currentFrame() - 1 : this.currentFrame();
    var vindex = 0;
    if ((index + 1) * this.frameWidth + this.startX > this.spriteSheet.width) {
        index -= Math.floor((this.spriteSheet.width - this.startX) / this.frameWidth);
        vindex++;
    }
    while ((index + 1) * this.frameWidth > this.spriteSheet.width) {
        index -= Math.floor(this.spriteSheet.width / this.frameWidth);
        vindex++;
    }

    var locX = x;
    var locY = y;
    var offset = vindex === 0 ? this.startX : 0;
    ctx.drawImage(this.spriteSheet,
                  index * this.frameWidth + offset, vindex * this.frameHeight + this.startY,  // source from sheet
                  this.frameWidth, this.frameHeight,
                  locX, locY,
                  this.frameWidth * scaleBy,
                  this.frameHeight * scaleBy);
	
}

Animation.prototype.currentFrame = function () {
    return Math.floor(this.elapsedTime / this.frameDuration);
}

Animation.prototype.isDone = function () {
    return (this.elapsedTime >= this.totalTime);
}

function Background(game) {
    Entity.call(this, game, 0, 400);
    this.radius = 200;
}

Background.prototype = new Entity();
Background.prototype.constructor = Background;

Background.prototype.update = function () {
}

Background.prototype.draw = function (ctx) {
    ctx.fillStyle = "SaddleBrown";
    ctx.fillRect(0,500,800,300);
    Entity.prototype.draw.call(this);
}
function BoundingBox(x, y, width, height, color) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;

    this.left = x;
    this.top = y;
    this.right = this.left + width;
    this.bottom = this.top + height;
    
    this.color = color
   
}

BoundingBox.prototype.collide = function (oth) {
    if (this.right > oth.left && this.left < oth.right && this.top < oth.bottom && this.bottom > oth.top){
    	oth.color = "Green"
    	return true;
    }
    return false;
}



/**
function Sidewalk(game) {
	this.sidewalk = new Animation(ASSET_MANAGER.getAsset("./img/Sidewalk.png"), 0, 0, 160, 75, 0.03, 1, true, false);
	
	this.radius = 200;
	Entity.call(this, game, 0, 500);
}

Sidewalk.prototype = new Entity();
Sidewalk.prototype.constructor = Sidewalk;

Sidewalk.prototype.update = function() { 
}

Sidewalk.prototype.draw = function(ctx) {
	for (var i = 0; i < 5; i++) {
		this.sidewalk.drawFrame(this.game.clockTick, ctx, this.x + (160 * i), this.y);
	}
	Entity.prototype.draw.call(this);
}
*/
/**
 * This function creates a generic platform
 * @param 
 * game is the standard game engine
 * x is an double that holds X-Value coordinates of the platform.
 * y is a double that holds the Y-Value of the platform.
 * length is a double that holds the length value of the platform drawn.
 * Height is a double that holds the height of the platform drawn.
 * 
 * @returns a generic platform with an entity call.
 * 
 * TODO: Add an addition paramater with a sprite animation to 
 * 		 fill in over the platform/shape drawn.
 */
function Platform(game, x, y, length, height, color) {
	this.radius = 100;
	this.color = color
	this.length = length;
	this.height = height
	this.x = x;
	this.y = y;
	
    this.boundingbox = new BoundingBox(x, y, length, height);

	
	Entity.call(this, game, x, y)
}
Platform.prototype = new Entity();
Platform.prototype.constructor = Platform;

Platform.prototype.draw = function (ctx) {
	ctx.fillStyle = this.color;
    ctx.fillRect(this.x,this.y,this.length,this.height);
    Entity.prototype.draw.call(this);
}
function Enemy(game, x, y) {
	this.left = new Animation(ASSET_MANAGER.getAsset("./img/dog.png"), 0, 250, 153, 115, 0.1, 4, true, false);
	this.right = new Animation(ASSET_MANAGER.getAsset("./img/dog.png"), 0, 0, 153, 115, 0.1, 6, true, false);
	this.l = true;
	this.r = false
	this.color = "Gold"
	this.length = 50;
	this.height = 100
	this.start = x
	this.x = x;
	this.y = y;
	this.count = 0;
	this.leftCheck = true;
	this.rightCheck = false
	Entity.call(this, game, x - 50, y -12)
}
Enemy.prototype = new Entity();
Enemy.prototype.constructor = Enemy;

Enemy.prototype.update= function() {
	this.x -= 4;
    if (this.x < -150) this.x = this.start;
    Entity.prototype.update.call(this);
	
}

Enemy.prototype.draw = function (ctx) {
	ctx.fillStyle = this.color;
	if(this.r){
		this.right.drawFrame(this.game.clockTick, ctx, this.x, this.y); 
	} else if(this.l){
		this.left.drawFrame(this.game.clockTick, ctx, this.x, this.y); 
	}
	
    //ctx.fillRect(this.x,this.y,this.length,this.height);
    Entity.prototype.draw.call(this);
}

function Cat(game) {
	this.neutralR = new Animation(ASSET_MANAGER.getAsset("./img/catBeta.png"), 0, 967, 96, 96, 0.03, 1, true, false);
	this.neutralL = new Animation(ASSET_MANAGER.getAsset("./img/catBeta.png"), 104, 967, 96, 96, 0.03, 1, true, false);
	this.attackAnim = new Animation(ASSET_MANAGER.getAsset("./img/catBeta.png"), 0, 0, 80, 150, 0.03, 9, false, false);
	this.jumpAnim = new Animation(ASSET_MANAGER.getAsset("./img/catBeta.png"), 0, 155, 80, 150, 0.03, 9, false, false);
	
	this.fallAnim = new Animation(ASSET_MANAGER.getAsset("./img/catBeta.png"), 0, 621, 80, 75, 0.03, 9, true, false);
	
	this.runRAnim = new Animation(ASSET_MANAGER.getAsset("./img/catBeta.png"), 0, 701, 128, 128, 0.1, 6, true, false);
	this.runLAnim = new Animation(ASSET_MANAGER.getAsset("./img/catBeta.png"), 0, 834, 128, 128, 0.1, 6, true, true);
	this.duckAnim = new Animation(ASSET_MANAGER.getAsset("./img/catBeta.png"), 0, 621, 80, 75, 0.03, 9, true, false);
	
    this.falling = false;
	this.x = 0;
	this.height = 150
	this.running = false;
	this.attacking = false;
	this.attackRange = 150		//The default attack range of the cat.
	this.ducking = false;
	this.jumping = false;
	this.left = false; 
	this.right = true;
	this.radius = 100;
	this.ground = 350;
	this.totalHeight = 30;
	this.platform = game.entities[0]
	
	this.boxes = true
	this.boundingbox = new BoundingBox(this.x, this.y, this.neutralR.frameWidth - 30, this.neutralR.frameHeight - 20, "Black");
	
	Entity.call(this, game, 20, 350);
}

Cat.prototype = new Entity();
Cat.prototype.constructor = Cat;
function distance(a, b) {
    var dx = a.x - b.x;
    var dy = a.y - b.y;
    return Math.sqrt(dx * dx + dy * dy);
}

Cat.prototype.collideDeath = function (other) {
    return this.y + this.height== other.y  && this.x < other.x + other.length
    		&& this.x + this.radius > other.x ;
    		
};
Cat.prototype.collideEnemy = function (other) {
    return this.x < other.x + other.length
	&& this.x + this.attackRange > other.x ;
	
};

/**
 * This function will detect if the cat reaches the 
 * leftmost boundary.
 */
Cat.prototype.collideLeft = function () {
    return (this.x - this.radius) < -100;
};
/**
 * This function will detect if the cat reches the 
 * rightmost boundary.
 */
Cat.prototype.collideRight = function () {
    return (this.x + this.radius) > 800;
};


Cat.prototype.update = function() {
	if (this.collideRight()) this.x = 800 - this.radius; //Checks boundry for right side of the map
	if (this.collideLeft()) this.x = this.radius-100; //Checks boundary for left side of the map
	
	var death = this.game.entities[3]
	var bad = this.game.entities[4]

	if(this.collideDeath(death)){
		this.removeFromWorld = false;
		death.color = "Blue"
	} else {
		death.color = "Red"
	}
	
	if (this.game.space) this.attacking = true;
	if (this.game.w) this.jumping = true;
	this.running = (this.game.right || this.game.left);

	this.ducking = this.game.down;
	if (this.attacking) {
		if(this.collideEnemy(bad)){		//This will remove the enemy when the player hits it.
			bad.removeFromWorld = true;
			
		} 
		if (this.attackAnim.isDone()) {
			this.attackAnim.elapsedTime = 0;
			this.attacking = false;
		}
	}
	if (this.running) {
		if (this.game.right) {
	        this.boundingbox = new BoundingBox(this.x + 35, this.y + 60, this.neutralR.frameWidth - 30, this.neutralR.frameHeight - 10, "Orange");
			this.x += 7;
			this.right = true;
			this.left = false;
		}
		else if (this.game.left) {
	        this.boundingbox = new BoundingBox(this.x, this.y + 60, this.neutralL.frameWidth - 35, this.neutralL.frameHeight - 10, "Purple");
			this.x -= 7;
			this.left = true;
			this.right = false;
		}
	}
	if (this.game.space && !this.jumping && !this.falling) {
        this.jumping = true;
        this.ground = this.y;
    }
	if (this.jumping) {		     
        if (this.jumpAnim.isDone()) {
            this.jumpAnim.elapsedTime = 0;
			this.jumping = false;
           // this.falling = true;
        }
        var jumpDistance = this.jumpAnim.elapsedTime / this.jumpAnim.totalTime;
       
        if (jumpDistance > 0.5)
            jumpDistance = 1 - jumpDistance;
		
        var height = this.totalHeight*(-40 * (jumpDistance * jumpDistance - jumpDistance)) ;
        //var height = jumpDistance * 2 * totalHeight;
        this.lastBottom = this.boundingbox.bottom;
        this.y = this.ground - height;
    	this.boundingbox = new BoundingBox(this.x + 40, this.y - 25, this.jumpAnim.frameWidth - 10, this.jumpAnim.frameHeight - 35, "Blue");
    	
        for (var i = 0; i < 3; i++) {
            var pf = this.game.entities[i];
            if (this.boundingbox.collide(pf.boundingbox) && this.lastBottom < pf.boundingbox.top) {
                this.jumping = false;
                this.y = pf.boundingbox.top - this.neutralR.frameHeight - 54;
      //          this.ground = this.y
                this.platform = pf;
                this.jumpAnim.elapsedTime = 0;
            } 
        }        
    }	
	if(this.falling){
		 //this.jumping = false
		 this.lastBottom = this.boundingbox.bottom;
         this.y += this.game.clockTick / this.jumpAnim.totalTime * 4 * this.totalHeight + 5;
    	 this.boundingbox = new BoundingBox(this.x + 35, this.y + 50, this.neutralL.frameWidth - 35, this.neutralL.frameHeight - 5, "Pink");
    	 
         for (var i = 0; i < 3; i++) {
             var pf = this.game.entities[i];
             if (this.boundingbox.collide(pf.boundingbox) && this.lastBottom < pf.boundingbox.top) {              
            	 this.falling = false;
                 this.y = pf.boundingbox.top - this.neutralR.frameHeight - 54;
             //    this.ground = this.y
                 this.platform = pf;
                 this.fallAnim.elapsedTime = 0;
             }
         }
	}
	if (!this.jumping && !this.falling) {
       // this.boundingbox = new BoundingBox(this.x + 35, this.y + 60, this.neutralL.frameWidth - 35, this.neutralL.frameHeight - 10, "Purple");
		/**
        if(this.game.right){
	        this.boundingbox = new BoundingBox(this.x + 35, this.y + 60, this.neutralL.frameWidth - 35, this.neutralL.frameHeight - 10, "Purple");
		} else if(this.game.left){
	        this.boundingbox = new BoundingBox(this.x - 5, this.y + 60, this.neutralL.frameWidth - 30, this.neutralL.frameHeight - 10, "Orange");
		}
		*/
        if (this.boundingbox.left > this.platform.boundingbox.right) this.falling = true;
    }
	Entity.prototype.update.call(this);
}

Cat.prototype.draw = function(ctx) {
	
	if(this.boxes){
		//ctx.strokeStyle = "red";
       // ctx.strokeRect(this.x + 25, this.y + 60, this.neutralL.frameWidth - 35, this.neutralL.frameHeight - 10);
        ctx.strokeStyle = this.boundingbox.color;
        ctx.strokeRect(this.boundingbox.x, this.boundingbox.y, this.boundingbox.width, this.boundingbox.height);
	}
	
	if (this.attacking) {
		this.attackAnim.drawFrame(this.game.clockTick, ctx, this.x, this.y, 2); 
	} 
	
	else if (this.jumping) {
		this.jumpAnim.drawFrame(this.game.clockTick, ctx, this.x + 50, this.y - 60);
		
	} else if (this.running && this.game.right) {
		this.runRAnim.drawFrame(this.game.clockTick, ctx, this.x, this.y + 25);
		
	} else if (this.running && this.game.left) {
		this.runLAnim.drawFrame(this.game.clockTick, ctx, this.x, this.y + 25);
		
	} else if (this.ducking) {
		this.duckAnim.drawFrame(this.game.clockTick, ctx, this.x, this.y + 75);
	} else {
		if (this.right) {
			this.neutralR.drawFrame(this.game.clockTick, ctx, this.x, this.y + 57);
		}
		if (this.left) {
			this.neutralL.drawFrame(this.game.clockTick, ctx, this.x, this.y + 57);
		}
	}

	Entity.prototype.draw.call(this);
}

var ASSET_MANAGER = new AssetManager();

ASSET_MANAGER.queueDownload("./img/catBeta.png");
ASSET_MANAGER.queueDownload("./img/dog.png");
//ASSET_MANAGER.queueDownload("./img/Sidewalk.png");
ASSET_MANAGER.downloadAll(function () {
    console.log("starting up da sheild");
    var canvas = document.getElementById('gameWorld');
    var ctx = canvas.getContext('2d');

    var gameEngine = new GameEngine();
   // var bg = new Background(gameEngine);
	var bg = new Platform(gameEngine, 0, 500, 800, 300, "SaddleBrown")
    gameEngine.addEntity(bg);	

	/**
	 * Generic platforms can be created, no more need to make a function for each
	 * platform made in the game.
	 * 
	 * var platformName = new Platform(gameEngine, X-Coordinate, Y-Coordinate, Length, Height)
	 *  
	 */
	var plat = new Platform(gameEngine, 100, 250, 100, 50, "Green");
	var p2 = new Platform(gameEngine, 400, 250, 100, 50, "Green")
	var cat = new Cat(gameEngine);
	var death = new Platform(gameEngine, 350, 500, 100, 20, "Red")
	var bad = new Enemy(gameEngine, 700, 400)
	//var sidewalk = new Sidewalk(gameEngine);
	//gameEngine.addEntity(sidewalk); 
    gameEngine.addEntity(plat);
    gameEngine.addEntity(p2);
    gameEngine.addEntity(death)
    gameEngine.addEntity(bad)
	gameEngine.addEntity(cat);
    gameEngine.init(ctx);
    gameEngine.start();
});
